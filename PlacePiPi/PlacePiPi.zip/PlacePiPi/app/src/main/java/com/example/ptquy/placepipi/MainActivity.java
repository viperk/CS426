package com.example.ptquy.placepipi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Handler;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Base64;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.ramotion.circlemenu.CircleMenuView;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

	private static int RESULT_LOAD_IMAGE = 1;
	Bitmap bm;
	ByteArrayOutputStream bos;
	byte[] bitmapdata;
	String imgdata;
	Uri selectedImage;
	Handler handler;
	ProgressDialog progressDialog;
	EditText ip;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ip = (EditText) findViewById(R.id.ip);
		ip.setText("");
		Button buttonLoadImage = (Button) findViewById(R.id.buttonLoadPicture);
		handler = new Handler(getApplicationContext().getMainLooper());

		progressDialog = new ProgressDialog(MainActivity.this);

		Button btn = (Button) findViewById(R.id.btntest);
		btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				Intent intent = new Intent(MainActivity.this, PlaceInfoActivity.class);
				intent.putExtra("placeID", "ChIJYemmUxkvdTERdbkQFU8zfsc");
				startActivity(intent);
			}
		});

		buttonLoadImage.setOnClickListener(new View.OnClickListener() {

			@Override
			public void onClick(View arg0) {

				/*Intent i = new Intent(
						Intent.ACTION_PICK,
						android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				startActivityForResult(i, RESULT_LOAD_IMAGE);*/

				if(!ip.getText().toString().trim().equals("")){
					Intent itent = new Intent(Intent.ACTION_GET_CONTENT);
					itent.setType("image/*");

					Intent pickitent = new Intent(
							Intent.ACTION_PICK,
							android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
					pickitent.setType("image/*");

					Intent chooseitent = Intent.createChooser(itent, "Select image");
					chooseitent.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{pickitent});

					startActivityForResult(chooseitent, RESULT_LOAD_IMAGE);
				}
				else{
					Toast.makeText(MainActivity.this, "Remember to enter server ip", Toast.LENGTH_SHORT).show();
				}
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);

		if (requestCode == RESULT_LOAD_IMAGE && resultCode == RESULT_OK && null != data) {
			Uri imguri = data.getData();
			selectedImage = imguri;
			ImageView imageView = (ImageView) findViewById(R.id.LoadedImage);
			imageView.setImageURI(imguri);
			try {
				bm = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImage);
			}catch(IOException ioe){

			}
			new HandleImage().execute(selectedImage);
		}
	}

	public class HandleImage extends AsyncTask<Uri, Void, String> {

		@Override
		protected void onPreExecute() {
			super.onPreExecute();

		}

		@Override
		protected void onPostExecute(String s) {
			super.onPostExecute(s);
		}

		@Override
		protected void onProgressUpdate(Void... values) {
			super.onProgressUpdate(values);

		}

		@Override
		protected String doInBackground(Uri... uris) {

			/*String[] filePathColumn = { MediaStore.Images.Media.DATA };

			Cursor cursor = getContentResolver().query(selectedImage,
					filePathColumn, null, null, null);
			cursor.moveToFirst();

			int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
			String picturePath = cursor.getString(columnIndex);
			cursor.close();

			ImageView imageView = (ImageView) findViewById(R.id.LoadedImage);
			imageView.setImageBitmap(BitmapFactory.decodeFile(picturePath));
			bm = BitmapFactory.decodeFile(picturePath);*/

			new Thread(new Runnable() {
				@Override
				public void run() {
					handler.post(new Runnable() {
						@Override
						public void run() {
							progressDialog.setMessage("Uploading, please wait...");
							progressDialog.show();
						}
					});
				}
			}).start();

			bos = new ByteArrayOutputStream();
			bm.compress(Bitmap.CompressFormat.JPEG, 100, bos);
			bitmapdata = bos.toByteArray();
			imgdata = Base64.encodeToString(bitmapdata, Base64.DEFAULT);

			//sending image to server
			StringRequest request = new StringRequest(Request.Method.POST, "http://"+ip.getText()+":8000/predict", new Response.Listener<String>(){
				@Override
				public void onResponse(String s) {
					progressDialog.dismiss();
					Toast.makeText(MainActivity.this, "Uploaded successfully " + s, Toast.LENGTH_LONG).show();
					Intent intent = new Intent(MainActivity.this, PlaceInfoActivity.class);
					intent.putExtra("placeID", s);
					startActivity(intent);
				}
			},new Response.ErrorListener(){
				@Override
				public void onErrorResponse(VolleyError volleyError) {
					progressDialog.dismiss();
					Toast.makeText(MainActivity.this, "Some error occurred -> "+volleyError, Toast.LENGTH_LONG).show();
				}
			}) {
				//adding parameters to send
				@Override
				protected Map<String, String> getParams() throws AuthFailureError {
					Map<String, String> parameters = new HashMap<String, String>();
					parameters.put("img", imgdata);
					return parameters;
				}
			};

			RequestQueue rQueue = Volley.newRequestQueue(MainActivity.this);
			rQueue.add(request);
			Integer tmp = imgdata.length();
			Log.d("quyen", String.valueOf(tmp));
			return imgdata;
		}
	}
}
