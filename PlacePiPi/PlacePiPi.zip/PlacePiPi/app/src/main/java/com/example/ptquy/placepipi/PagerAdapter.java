package com.example.ptquy.placepipi;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.util.Log;

public class PagerAdapter extends FragmentPagerAdapter{

	private String placedata;
	public PagerAdapter(FragmentManager fm, String place) {
		super(fm);
		this.placedata = place;
		Log.d("kkkk", place);
	}
	@Override
	public Fragment getItem(int position) {
		Fragment frag = null;
		Bundle bundle = new Bundle();
		bundle.putCharSequence("placedata", placedata);

		switch (position){
			case 0:
				frag = new PlaceInfoFragment();
				frag.setArguments(bundle);
				break;
			case 1:
				frag = new PlaceImagesFragment();
				frag.setArguments(bundle);
				break;
			case 2:
				frag = new ReviewsFragment();
				frag.setArguments(bundle);
				break;
		}
		return frag;
	}

	@Override
	public int getCount() {
		return 3;
	}

	@Nullable
	@Override
	public CharSequence getPageTitle(int position) {
		String title = "";
		switch (position){
			case 0:
				title = "Overview";
				break;
			case 1:
				title = "Images";
				break;
			case 2:
				title = "Reviews";
				break;
		}
		return title;
	}
}
