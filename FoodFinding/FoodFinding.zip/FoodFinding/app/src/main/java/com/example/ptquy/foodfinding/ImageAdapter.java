package com.example.ptquy.foodfinding;

public class ImageAdapter {
}
