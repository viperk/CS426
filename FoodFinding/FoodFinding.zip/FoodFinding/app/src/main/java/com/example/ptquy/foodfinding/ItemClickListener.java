package com.example.ptquy.foodfinding;

import android.view.View;

public interface ItemClickListener {
	void onClick(View view, int position, boolean isLongClick);
}
