package com.example.ptquy.foodfinding;

public class placeIDObject {
	private String placeID;

	public placeIDObject(){

	}

	public placeIDObject(String placeID) {
		this.placeID = placeID;
	}

	public String getPlaceID() {
		return placeID;
	}

	public void setPlaceID(String placeID) {
		this.placeID = placeID;
	}
}
